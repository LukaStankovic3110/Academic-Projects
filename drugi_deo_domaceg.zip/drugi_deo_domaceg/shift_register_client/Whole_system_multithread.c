#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include "MQTTClient.h"
#include <time.h>

#define QOS 1
#define TIMEOUT 10000L

#define ADDRESS "broker.hivemq.com:1883"

#define CLIENTID_A "Number_A"
#define CLIENTID_B "Number_B"
#define CLIENTID_SUM "SUM_segment"
#define CLIENTID_Y "Y_segment"
#define CLIENTID_CU "Control_unit"

#define TOPIC_A "MQTT_topic_register_A"
#define TOPIC_B "MQTT_topic_register_B"
#define TOPIC_A_bit "MQTT_topic_register_A_bit"
#define TOPIC_B_bit "MQTT_topic_register_B_bit"
#define TOPIC_F "MQTT_One_bit_result"
#define TOPIC_CLR "MQTT_clr_signal"
#define TOPIC_CLK1 "MQTT_loading_clk"
#define TOPIC_CLK2 "MQTT_clk2"
#define TOPIC_READY "MQTT_ready"
#define TOPIC_START "MQTT_start"
#define TOPIC_RESULT "MQTT_result"

struct RegAContext {
    bool clk_flag;
    uint8_t bit_counter;
    uint32_t A_value;
};

struct RegBContext {
    bool clk_flag;
    uint8_t bit_counter;
    uint32_t B_value;
};

struct SumContext {
    uint8_t A_bit;
    uint8_t B_bit;
    uint8_t cnt;
    uint8_t carry_bit;
};

struct RegYContext {
    uint8_t tmp;
    uint32_t result;
    uint8_t cnt;
};

struct centralUnitContext {
    uint8_t cnt;
    bool active_state;
    bool informing_user;
};

DWORD threadID;

void delivered(void *context, MQTTClient_deliveryToken dt) {
    //printf("[DELIVERED] Message with token %d delivered\n", dt);
}

void connlost(void *context, char *cause) {
    printf("\n[CONNECTION LOST] Cause: %s\n", cause);
}

int Reg_A_callback_function(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    struct RegAContext *current = (struct RegAContext *)context;

    if(strcmp(topicName, TOPIC_A) == 0) {
        char *str = (char*)message->payload;
        current->A_value = (uint32_t)atoi(str);
        printf("[RegA] Received value: %u\n", current->A_value);
    } else if(strcmp(topicName, TOPIC_CLK1) == 0) {
        current->clk_flag = true;
       // printf("[RegA] CLK1 received\n");
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

int Reg_B_callback_function(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    struct RegBContext *current = (struct RegBContext *)context;

    if(strcmp(topicName, TOPIC_B) == 0) {
        char *str = (char*)message->payload;
        current->B_value = (uint32_t)atoi(str);
        printf("[RegB] Received value: %u\n", current->B_value);
    } else if(strcmp(topicName, TOPIC_CLK1) == 0) {
        current->clk_flag = true;
       // printf("[RegB] CLK1 received\n");
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

int Sum_segment_callback_function(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    struct SumContext *current = (struct SumContext *)context;

    if(strcmp(topicName, TOPIC_CLR) == 0) {
        current->B_bit = 0;
        current->A_bit = 0;
        current->cnt = 0;
       // printf("[SUM] Clear signal received\n");
    } else if(strcmp(topicName, TOPIC_B_bit) == 0) {
        current->B_bit = *(uint8_t*) message->payload;
        current->cnt++;
      //  printf("[SUM] Received B_bit: %u\n", current->B_bit);
    } else if(strcmp(topicName, TOPIC_A_bit) == 0) {
        current->A_bit = *(uint8_t*) message->payload;
        current->cnt++;
      //  printf("[SUM] Received A_bit: %u\n", current->A_bit);
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

int Y_segment_callback_function(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    struct RegYContext *current = (struct RegYContext *)context;

    if(strcmp(topicName, TOPIC_F) == 0) {
        uint8_t byte_val = *(uint8_t*) message->payload;
        current->tmp = byte_val;
       // printf("[Y_SEG] Received bit: %u\n", current->tmp);
    } else if(strcmp(topicName, TOPIC_CLK2) == 0) {
        current->result |= (current->tmp << current->cnt++);
      //  printf("[Y_SEG] Updated result: %u, cnt: %u\n", current->result, current->cnt);
    } else if(strcmp(topicName, TOPIC_CLR) == 0) {
        current->result = 0;
        current->cnt = 0;
        current->tmp = 0;
     //   printf("[Y_SEG] Clear signal received\n");
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

int Control_unit_callback_function(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    struct centralUnitContext *current = (struct centralUnitContext *)context;

    if(strcmp(topicName, TOPIC_START) == 0) {
        if(!current->active_state) {
            current->active_state = true;
            current->informing_user = true;
            current->cnt = 0;
            printf("[CU] START signal received, activating system\n");
        }
    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

void connect_segment(MQTTClient* client, int (*func)(void *, char *, int, MQTTClient_message*), const char ** topics , int topics_len, const char* CLIENTID, void* context) {
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    int rc;

    MQTTClient_create(client, ADDRESS, CLIENTID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;

    MQTTClient_setCallbacks(*client, context, connlost, func, delivered);

    if ((rc = MQTTClient_connect(*client, &conn_opts)) != MQTTCLIENT_SUCCESS) {
        printf("Failed to connect %s, return code %d\n", CLIENTID, rc);
        exit(EXIT_FAILURE);
    } else {
        printf("[MQTT] Connected client %s\n", CLIENTID);
    }

    for(int i = 0; i < topics_len; i++) {
        MQTTClient_subscribe(*client, topics[i], QOS);
    //    printf("[MQTT] Subscribed to topic: %s\n", topics[i]);
    }
}

void Shift_register_A(void *arg) {
    struct RegAContext params = {0};
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;
    MQTTClient client;

    const char* topics[] = {TOPIC_A, TOPIC_CLK1};
    connect_segment(&client, Reg_A_callback_function, topics, 2, CLIENTID_A, &params);

    while(1) {
        if(params.clk_flag) {
            uint8_t bit = (params.A_value >> params.bit_counter) & 1;
            pubmsg.payload = &bit;
            pubmsg.payloadlen = sizeof(bit);
            pubmsg.qos = QOS;
            pubmsg.retained = 0;

            MQTTClient_publishMessage(client, TOPIC_A_bit, &pubmsg, &token);
            rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);

    //        printf("[RegA] Published bit %u, bit_counter %u\n", bit, params.bit_counter);

            params.bit_counter++;
            params.clk_flag = false;
            if(params.bit_counter == 32) params.bit_counter = 0;
        }
    }
}

void Shift_register_B(void *arg) {
    struct RegBContext params= {0};
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;
    MQTTClient client;

    const char* topics[] = {TOPIC_B, TOPIC_CLK1};
    connect_segment(&client, Reg_B_callback_function, topics, 2, CLIENTID_B, &params);

    while(1) {
        if(params.clk_flag) {
            uint8_t bit = (params.B_value >> params.bit_counter) & 1;
            pubmsg.payload = &bit;
            pubmsg.payloadlen = sizeof(bit);
            pubmsg.qos = QOS;
            pubmsg.retained = 0;

            MQTTClient_publishMessage(client, TOPIC_B_bit, &pubmsg, &token);
            rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);

        //    printf("[RegB] Published bit %u, bit_counter %u\n", bit, params.bit_counter);

            params.bit_counter++;
            params.clk_flag = false;
            if(params.bit_counter == 32) params.bit_counter = 0;
        }
    }
}

// ---- Sum element thread ----
void Sum_element(void *arg) {
    struct SumContext params = {0};
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;
    MQTTClient client;

    const char* topics[] = {TOPIC_B_bit, TOPIC_A_bit, TOPIC_CLR};
    connect_segment(&client, Sum_segment_callback_function, topics, 3, CLIENTID_SUM, &params);

    while(1) {
        if(params.cnt == 2) {
            uint8_t sum = params.A_bit + params.B_bit + params.carry_bit;
            uint8_t bit = sum & 1;
            params.carry_bit = (sum >> 1) & 1;

            pubmsg.payload = &bit;
            pubmsg.payloadlen = sizeof(bit);
            pubmsg.qos = QOS;
            pubmsg.retained = 0;

            MQTTClient_publishMessage(client, TOPIC_F, &pubmsg, &token);
            rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);

        //    printf("[SUM] Published sum bit: %u, carry: %u\n", bit, params.carry_bit);

            params.cnt = 0;
        }
        
    }
}

// ---- Y segment thread ----
void Y_segment(void *arg) {
    struct RegYContext params = {0};
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;
    MQTTClient client;

    const char* topics[] = {TOPIC_CLR, TOPIC_F, TOPIC_CLK2};
    connect_segment(&client, Y_segment_callback_function, topics, 3, CLIENTID_Y, &params);

    while(1) {
        if(params.cnt == 31) {
            char result_str[12];
            sprintf(result_str, "%u", params.result);

            pubmsg.payload = result_str;
            pubmsg.payloadlen = strlen(result_str);
            pubmsg.qos = QOS;
            pubmsg.retained = 0;

            MQTTClient_publishMessage(client, TOPIC_RESULT, &pubmsg, &token);
            MQTTClient_waitForCompletion(client, token, TIMEOUT);

            printf("[Y_SEG] Published final result: %s\n", result_str);

            params.cnt = 0;
            params.result = 0;
        }
    }
}

// ---- Central unit thread ----
void Central_unit(void *arg) {
    struct centralUnitContext params = {0};
    MQTTClient client;
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;

    const char* topics[] = {TOPIC_START};
    connect_segment(&client, Control_unit_callback_function, topics, 1, CLIENTID_CU, &params);

    uint8_t ready = 1;
    pubmsg.payload = &ready;
    pubmsg.payloadlen = sizeof(ready);
    pubmsg.qos = QOS;
    pubmsg.retained = 0;

    MQTTClient_publishMessage(client, TOPIC_READY, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, TIMEOUT);

    uint8_t pulse = 1;
    pubmsg.payload = &pulse;
    pubmsg.payloadlen = sizeof(pulse);
    MQTTClient_publishMessage(client, TOPIC_CLR, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, TIMEOUT);

    clock_t start = clock();
    double period = 0.5;
    double half_period = 0.5;
    int clk_state = 0;

    while(1) {
	    if(params.active_state && params.cnt == 0) {
	        // --- Reset svih segmenata pre nove kalkulacije ---
	        uint8_t clr_signal = 1;
	        MQTTClient_message pubmsg = MQTTClient_message_initializer;
	        MQTTClient_deliveryToken token;
	
	        pubmsg.payload = &clr_signal;
	        pubmsg.payloadlen = sizeof(clr_signal);
	        pubmsg.qos = QOS;
	        pubmsg.retained = 0;
	
	        // Pošalji CLR signal pre početka CLK
	        MQTTClient_publishMessage(client, TOPIC_CLR, &pubmsg, &token);
	        MQTTClient_waitForCompletion(client, token, TIMEOUT);
	
	        printf("[CU] CLR pulse sent before new calculation\n");
	    }
	
	    // --- CLK1 / CLK2 logic ---
	    double elapsed = (double)(clock() - start) / CLOCKS_PER_SEC;
	    if(params.active_state && params.cnt <32) {
	        if(clk_state == 0 && elapsed >= period) {
	            MQTTClient_publishMessage(client, TOPIC_CLK1, &pubmsg, &token);
	            MQTTClient_waitForCompletion(client, token, TIMEOUT);
	            start = clock();
	            clk_state = 1;
	            params.cnt++;
	        //    printf("[CU] CLK1 pulse sent, cnt: %u\n", params.cnt);
	        } else if(clk_state == 1 && elapsed >= half_period) {
	            MQTTClient_publishMessage(client, TOPIC_CLK2, &pubmsg, &token);
	            MQTTClient_waitForCompletion(client, token, TIMEOUT);
	            start = clock();
	            clk_state = 0;
	        //    printf("[CU] CLK2 pulse sent\n");
	        }
	    } else if(params.active_state) {
	        // Kalkulacija završena, reset
	       // params.cnt = 0;
	        params.active_state = false;
	        uint8_t ready = 1;
	        pubmsg.payload = &ready;
	        pubmsg.payloadlen = sizeof(ready);
	        MQTTClient_publishMessage(client, TOPIC_READY, &pubmsg, &token);
	        MQTTClient_waitForCompletion(client, token, TIMEOUT);
	        printf("[CU] Sequence finished, ready reset\n");
	    }
	}
}

// ---- MAIN ----
int main(int argc, char *argv[]) {
    HANDLE reg_A_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) Shift_register_A, NULL, CREATE_SUSPENDED, &threadID);
    HANDLE reg_B_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) Shift_register_B, NULL, CREATE_SUSPENDED, &threadID);
    HANDLE SUM_element_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) Sum_element, NULL, CREATE_SUSPENDED, &threadID);
    HANDLE Y_segment_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) Y_segment, NULL, CREATE_SUSPENDED, &threadID);
    HANDLE Central_unit_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) Central_unit, NULL, CREATE_SUSPENDED, &threadID);

    ResumeThread(reg_A_thread);
    ResumeThread(reg_B_thread);
    ResumeThread(SUM_element_thread);
    ResumeThread(Y_segment_thread);
    ResumeThread(Central_unit_thread);

    printf("[MAIN] All threads started\n");

    while(1) {
        Sleep(1000);
    }

    return 0;
}