% Parameters
clear all;
close all;
%%
load eegdata.mat
%% Ucitavanje EEG podataka - Zadatak 2
% Subjekat 1, peti zadatak, prvi kanal

chap9ex = data{50}{4}(1,:);  % C3 snimak
fs= 250;
TotalTime = 10;
N = fs * TotalTime;
t = 0:1/fs:TotalTime - 1/fs;


%% Zadatak 2
% Prikaz prvih 5 sekundi signala
eegchannel = chap9ex;
figure
    plot(t, eegchannel, 'Color', [0 0 0]);
      title('Prvih 10 sekundi signala drugog subjekta, tokom prvog zadatka, sa drugog kanala');
      xlim([0, 10]);
      xlabel('Vreme [s]');
      ylabel('Amplituda [\muV]' ); 
      grid on;

 %% % Example signal

% Compute spectrogram
%velicina prozora u odbircima 
Nwin = 32;  
%broj preklopljenih odbiraka
noverlap = floor(Nwin/2); 
% u koliko tacaka radimo fft
Nfft = 1024;  

window =hamming(Nwin);

[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, Nfft);
[~,F,T,P] = spectrogram(eegchannel,window,noverlap,Nfft,fs);
% Plot using imagesc
figure;
subplot(2,1,1);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija');

subplot(2,1,2);
imagesc(T, F, 10*log10(P)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spectrogram']);
%%
figure;
subplot(2,2,1);
tic
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window));
toc
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija Nfft= 32');

subplot(2,2,2);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*2);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spect_ alternative funkcija Nfft= 64']);

subplot(2,2,3);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*3);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija Nfft= 96');

subplot(2,2,4);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*4);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spect_ alternative funkcija Nfft= 128']);


%%
figure;
subplot(2,2,1);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*5);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija Nfft= 160');

subplot(2,2,2);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*6);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spect_ alternative funkcija Nfft= 192']);

subplot(2,2,3);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*7);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija Nfft= 224');

subplot(2,2,4);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*8);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spect_ alternative funkcija Nfft= 256']);
%%
figure;
subplot(2,2,1);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*9);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija Nfft= 288');

subplot(2,2,2);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*10);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spect_ alternative funkcija Nfft= 320']);

subplot(2,2,3);
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*30);
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title('spect_ alternative funkcija Nfft=960');

subplot(2,2,4);
tic
[y, f, t] = spect_alternative(eegchannel, fs, window, fs/2,noverlap, length(window)*100);
toc
imagesc(t, f, 10*log10(y)); % Convert power to dB
axis xy;                    % Flip Y-axis to show frequencies correctly
colorbar;
colormap('jet');% Add color bar
xlabel('Vreme (s)');
ylabel('f (Hz)');
title(['spect_ alternative funkcija Nfft= 3200']);
