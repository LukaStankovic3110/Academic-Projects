function [y, f, t] = spect_alternative(x, fs, window,fMaxShow, noverlap, Nfft)
%ogranicavamo da se unese frekvencija veca maksimalne u spektru
 if fMaxShow > fs/2
     fMaxShow = fs/2;
 end

 x_length=length(x);
 Ts=1/fs;
 window_length=length(window);
 %prvi blok nema preklapanja
 number_of_blocks = 1 + ceil((x_length-window_length)/(window_length-noverlap));
 time_indecies= [0 window_length];
 %pravi se matrica koja reprezentuje kasniju sliku koja se formira 
 y = zeros(Nfft, number_of_blocks);

        for i = 1:(number_of_blocks)
            if i == 1 
                y(:, 1) = fft(x(1:window_length)' .* window, Nfft);

            elseif i ~=number_of_blocks
                %ceo signal je podeljen na 1.paket duzine window_length dok
                %su ostali dobijeni deljenjem ostatka signala sa
                %window_length-noverlap, jer je za svaki paket podataka
                %to je jedinstvena celina a noverlap podataka se na to prikaci
                %od prethodnih podataka i time se ostvari poklapanje
                %podeoka za noverlap duzinu.
                y(:, i) = fft(x( window_length + 1 + (i-2)*(window_length-noverlap) - noverlap : ...
                    window_length + (i-1)*(window_length-noverlap))'.* window, Nfft);
                time_indecies = [time_indecies  (window_length + (i-1)*(window_length-noverlap))];
            else 
                % poslednji paket je prosiren celinom dovoljnom da se ceo
                % prozor obuhvati od kraja. Kako ne bi zbog ostatka pri
                % deljenju sa window_length-noverlap dobili mali broj
                % podataka na kraju i onda zbog mnozenja sa window ne bismo
                % morali da dodajemo dodatne nule, pa jos i ako je Nfft
                % vece od window_length u fft-u bi se vrsilo jos jedno
                % dadatno popunjavanje nulama, samo je uzeto window_length broj podataka sa
                % kraja.
               y(:, i) = fft(x((end-window_length+1) : end)'.*window, Nfft);

            end
        end

% prikupljeni indeksi trenutaka u kojima se zavrsava svaki paket / tacke u kojima dolazi do preklapanja dva paketa  
 t = time_indecies * Ts;
 k = 0:((Nfft-1)/2);              
 f = fs * k / Nfft; 
 %maksimalna frekvencija koju zelimo da prikazemo, ukoliko zelimo da
 %zumiramo spektrogram na primer. Podeseno da maksimalno prikazuje fs/2; 
 fMaxIndex = floor((Nfft * fMaxShow) / fs);
 y = y(1:fMaxIndex, :);
 f = f(1:fMaxIndex);
 y=abs(y).^2;
