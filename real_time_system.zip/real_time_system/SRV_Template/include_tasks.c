#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "event_groups.h"
#include "includes.h"

/* Hardware includes. */
#include "msp430.h"
#include "ETF5529_HAL/hal_ETF_5529.h"

void starting_initialization(void)
{
    __disable_interrupt(); //
    WDTCTL = WDTPW + WDTHOLD;
    hal430SetSystemClock(configCPU_CLOCK_HZ, configLFXT_CLOCK_HZ);

    // Pin za taster
    P1DIR &= ~(BIT4+BIT5);
    P1REN |= BIT4+BIT5;
    P1OUT |= BIT4+BIT5;

    P1IE |= BIT4+BIT5;  //
    P1IFG &=~ (BIT4+BIT5);
    P1IES |= BIT4+BIT5; //




     P6SEL |= BIT0 | BIT1;  // P6.0 (A0) i P6.1 (A1) kao analogni ulazi
     ADC12CTL0 = ADC12SHT0_2 | ADC12MSC | ADC12ON; // Sample & Hold = 16 ciklusa, Multiple Sample Conversion, ADC On
     ADC12CTL1 = ADC12CSTARTADD_0 | ADC12SHS_0 | ADC12SHP | ADC12CONSEQ_1;
     ADC12MCTL0 = ADC12INCH_0; // A0 -> MEM0
     ADC12MCTL1 |= ADC12INCH_1 | ADC12EOS; // A1 -> MEM1 (EOS - end of sequence)
     ADC12IE = ADC12IE0 | ADC12IE1;
     ADC12CTL0 |= ADC12ENC;

     P4SEL       |= BIT4 + BIT5;    // Set P1.1 and P1.2 to UART TX/RX


     // P4.4,5 = USCI_AA TXD/RXD
     UCA1CTL1    |= UCSWRST;                      // **Put state machine in reset**
     UCA1CTL1    |= UCSSEL_2;                     // SMCLK
     UCA1BRW      = 1041;                            // 1MHz 115200
     UCA1MCTL    |= UCBRS_6 + UCBRF_0;            // Modulation UCBRSx=1, UCBRFx=0
     UCA1CTL1    &= ~UCSWRST;                     // **Initialize USCI state machine**
     UCA1IE      |= UCRXIE;

    vHALInitLED();

    __enable_interrupt(); //
}

