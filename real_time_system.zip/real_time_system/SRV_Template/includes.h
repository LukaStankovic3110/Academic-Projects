/*
 * includes.h
 *
 *  Created on: 06.02.2025.
 *      Author: Admin
 */

#include <FreeRTOS.h>

void starting_initialization(void);
