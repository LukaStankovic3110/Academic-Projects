#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "event_groups.h"

/* Hardware includes. */
#include "msp430.h"
#include "ETF5529_HAL/hal_ETF_5529.h"
#include "includes.h"

/* Korisni definisani objekti */

#define ULONG_MAX                       0xFFFFFFFF
#define mainDIODE_CHANGE_STATE_PERIOD_MS    1500
#define ascii2digit(x)                  (x + '0')
#define CHANNEL_A0_MASK                 0x0000
#define CHANNEL_A1_MASK                 0x0100



TaskHandle_t xTask1Handle ;
TaskHandle_t xTask2Handle;
TaskHandle_t xTask3Handle;
xQueueHandle        xQueue1;
xQueueHandle        xQueue2_1;
xQueueHandle        xQueue2_2;
xQueueHandle        xQueueT2;

/* Software Timer handler*/
TimerHandle_t       adc_timer;



typedef enum {
    led3on,
    led4on
}led_state_t;




static void xTask1(void *pvParameters)
{
    uint16_t NewValueToShow = 0 ;
    uint8_t i ;
    float avarage_A0 = 0;
    float avarage_A1 = 0;
    static uint8_t conversion_results_A0[4] = {0,0,0,0};
    static uint8_t conversion_results_A1[4] = {0,0,0,0};



    for (;;)
    {
        /* Čekaj na događaj (semafor) */
        ulTaskNotifyTake(pdTRUE,portMAX_DELAY);
        while(xQueueReceive(xQueue1, &NewValueToShow, 0) == pdTRUE )
        {
            if((NewValueToShow>>8) != 0)//A1
            {
              for(i=0 ; i<3 ;i ++)
              {
                  conversion_results_A1[i]=conversion_results_A1[i+1];
              }
              conversion_results_A1[3] = 0xFF & NewValueToShow;
              avarage_A1 = (conversion_results_A1[0] + conversion_results_A1[1] + conversion_results_A1[2] + conversion_results_A1[3])/ 4;
              xQueueOverwrite( xQueue2_2, &avarage_A1 );
            }


            else//A0
            {
                for(i=0 ; i<3 ;i ++)
                {
                    conversion_results_A0[i]=conversion_results_A0[i+1];
                }
                conversion_results_A0[3] = 0xFF & NewValueToShow;
                avarage_A0 = (conversion_results_A0[0] + conversion_results_A0[1] + conversion_results_A0[2] + conversion_results_A0[3])/4;
                xQueueOverwrite( xQueue2_1, &avarage_A0 );
            }
        }
    }
}



static void xTask2(void *pvParameters)
{
    uint8_t flag = 0 ;
    uint16_t boundery = 100 ;
    uint16_t received_value;
    float A0_average = 0.0;
    float A1_average =0.0;
    char    string1[]="- LED3 sija  \r\n";
    char    string2[]="- LED3 je ugasen \r\n";
    char    string3[]="- LED4  sija \r\n";
    char    string4[]="- LED4 je ugasen \r\n";
    char* tmp ;
    uint16_t storage_boundery = 0;
    uint8_t i = 3 ;

    for (;;)
    {
        flag = 0;
        xQueueReceive(xQueue2_1, &A0_average, 0) ;
        xQueuePeek(xQueue2_2, &A1_average, 0) ;


        while(xQueueReceive(xQueueT2, &received_value, 0) == pdTRUE)
        {


            if((received_value>>12 )!= 0 )
            {
                boundery = boundery - 30;
                flag = 1 ;
            }
            else if ((received_value>>8 )!= 0)
            {
                boundery = boundery + 30;
                flag = 1 ;
            }
            else
            {
                if(received_value == 'b')
                {

                    boundery = 100*(storage_boundery>>8) + 10*((storage_boundery>>4)& 0x0F) + (storage_boundery & 0x0F) ;
                    storage_boundery = 0x0000;
                    i = 3;
                    flag = 1 ;
                }
                else
                {
                    if (i!= 0)
                    {
                    storage_boundery |= (uint8_t)(received_value - '0') <<(4*(i-1));
                    i--;
                    }
                }

            }
        }

        if(A0_average>boundery)
            {
                halSET_LED(LED4) ;
                tmp   =   string3;
                if(flag)
                {
                    while(*tmp != 0){
                                while(!(UCA1IFG&UCTXIFG));
                                UCA1TXBUF = *tmp;
                                tmp += 1;
                }
                }



            }
         else
            {
                halCLR_LED(LED4) ;
                tmp   =   string4;
                if(flag)
                {
                    while(*tmp != 0){
                                while(!(UCA1IFG&UCTXIFG));
                                UCA1TXBUF = *tmp;
                                tmp += 1;
                }
                }
            }
         if(A1_average>boundery)
            {
                halSET_LED(LED3) ;
                tmp   =   string1;
                if(flag)
                {
                    while(*tmp != 0){
                                while(!(UCA1IFG&UCTXIFG));
                                UCA1TXBUF = *tmp;
                                tmp += 1;
                }
                }
            }
         else
            {
                halCLR_LED(LED3) ;
                tmp   =   string2;
                if(flag)
                {
                    while(*tmp != 0){
                                while(!(UCA1IFG&UCTXIFG));
                                UCA1TXBUF = *tmp;
                                tmp += 1;
                }
                }
            }
         flag = 0;


    }




}
static void xTask3(void *pvParameters)
{
        uint16_t message ;
        uint8_t currentButtonState;
        uint16_t i ;

        for ( ;; )
        {

            ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
                    /*wait for a little to check that button is still pressed*/
            for(i = 0; i < 1000; i++);
                    /* check if button SW3 is pressed*/
            currentButtonState = ((P1IN & 0x10) >> 4);
            if(currentButtonState == 0){
                        /* If S3 is pressed set ADC task notification value bit defined
                         * with mainADC_TAKE_SAMPLE mask */
                message = 0x1000 ; // DEKREMENTIRAJ VREDNOST
                xQueueSend(xQueueT2, &message, portMAX_DELAY);
                continue;
            }
                    /* check if button S4 is pressed*/
            currentButtonState = ((P1IN & 0x20) >> 5);
            if(currentButtonState == 0){
                        /* If S4 is pressed set ADC task notification value bit defined
                         * with mainADC_CHANGE_CHANEL mask */
                message = 0x0100 ; // INKREMENTARJ VREDNOST
                xQueueSend(xQueueT2, &message, portMAX_DELAY);
                continue;
            }
        }
}



void    ad_conversion_callback(TimerHandle_t adc_timer){
    ADC12CTL0 &= ~ADC12ENC;  // Onemogući ADC pre podešavanja
    ADC12CTL0 |= ADC12SC |  ADC12ENC;;    // Startuj konverziju

}


void main(void)
{
    starting_initialization();

    // Kreiranje zadataka
    xTaskCreate(xTask1,
                "Task1",
                configMINIMAL_STACK_SIZE,
                NULL,
                2,
                &xTask1Handle);

    xTaskCreate(xTask2,
                "Task2",
                configMINIMAL_STACK_SIZE,
                NULL,
                1,
                &xTask2Handle);
    xTaskCreate(xTask3,
                "Task3",
                configMINIMAL_STACK_SIZE,
                NULL,
                3,
                &xTask3Handle);

    adc_timer= xTimerCreate(" adc_timer",
                                       pdMS_TO_TICKS(mainDIODE_CHANGE_STATE_PERIOD_MS),
                                       pdTRUE,
                                       NULL,
                                       ad_conversion_callback);


    xQueue1      =   xQueueCreate(2,sizeof(uint16_t));
    xQueue2_1       =   xQueueCreate(1,sizeof(float));
    xQueue2_2       =   xQueueCreate(1,sizeof(float));
    xQueueT2       =   xQueueCreate(10,sizeof(uint16_t));




    __enable_interrupt(); // Omogući prekide
    xTimerStart(adc_timer, 0);

    // Pokreni FreeRTOS scheduler
    vTaskStartScheduler();

    // Ako se desi greška (sceduler neće da se pokrene)
    while (1);
}

__attribute__((interrupt(ADC12_VECTOR)))
void ADC_interrupt(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint16_t tmp1;
    uint16_t tmp2 ;
    // Proveri da li je taster pritisnut
    if ((ADC12IFG & ADC12IFG0 ) == (ADC12IFG0 ))
    {
        tmp1 = CHANNEL_A0_MASK | ((uint16_t)(ADC12MEM0>>4));
        xQueueSendToBackFromISR(xQueue1,&tmp1,&xHigherPriorityTaskWoken);
    }
    if ((ADC12IFG & ADC12IFG1) == ADC12IFG1)
    {
        tmp2 = CHANNEL_A1_MASK | ((uint16_t)(ADC12MEM1>>4));
        xQueueSendToBackFromISR(xQueue1,&tmp2,&xHigherPriorityTaskWoken);
    }
    vTaskNotifyGiveFromISR(xTask1Handle, &xHigherPriorityTaskWoken);



    // Ako je potrebno, prebacivanje zadatka
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}


__attribute__((interrupt(PORT1_VECTOR)))
void PORT1_interrupt(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    // Proveri da li je taster pritisnut
    if (((P1IFG & BIT4) == BIT4) || ((P1IFG & BIT5) == BIT5))
    {
        vTaskNotifyGiveFromISR(xTask3Handle, &xHigherPriorityTaskWoken);
    }

    // Očisti interrupt flag
    P1IFG &=~0x32;

    // Ako je potrebno, prebacivanje zadatka
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}


__attribute__((interrupt(USCI_A1_VECTOR)))
void UART_interrupt(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint16_t  tmp;

    // Proveri da li je taster pritisnut
    if ((UCA1IFG & UCRXIFG)!= 0)
    {
            tmp = UCA1RXBUF;
            xQueueSendToBackFromISR(xQueueT2,&tmp,&xHigherPriorityTaskWoken);

    }


    // Ako je potrebno, prebacivanje zadatka
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
