rddata
close all;
%%
signal = M(:,1);
time = TIME;
fs = 360;
% nikvistov kriterijum za baznu liniju je 0.6 Hz ukoliko uzmemo da to bude
% 80% od fs_max trebalo  bi da je frekvencija odabiranja 0.8 Hz. Radi verne
% rekonstrukcije bazne linije potrebno je uzimati negde u okolini 
% 360/0.8 = 450. Dakle svaki 450. odbirak signala kom je pridruzen
% respiratorni sum na 0.3 Hz .
% trajanje qrs komplesa je oko 80 ms sto znaci da opseg suzavanja treba da
% bude ispod toga mi uzimamo kao opsti primer da hocemo poravnati okolinu
% od po 15 ms sa obe strane pika 

resampling = 450;
duration_of_band = 0.03;
amp = 0.3;
%%
figure
    spectar = abs(fftshift(fft(signal)));
    N = length(signal);
    f = fs*(0:N-1)/N -fs/2;
    plot(f, spectar);
    xlim([-fs/2,fs/2]);
    xlabel('Frekvencija [ Hz ]');
    ylabel('Amplituda [mV / Hz]' );
    title('Spektar signala pre filtracije');
    grid on;


    %%
    fs_max = fs/2;
    [b1,a1] = butter(5,1/fs_max,'high');
    [b2,a2] = butter(5,[58 61]/fs_max,'stop');
    y1 = filtfilt(b1,a1,signal);
    filtered_signal = filtfilt(b2,a2,y1);

    figure
    spectar_filtered_signal = abs(fftshift(fft(filtered_signal)));
    f = fs*(0:N-1)/N-fs/2;
    plot(f, spectar_filtered_signal);
    xlim([-fs/2,fs/2]);
    xlabel('Frekvencija [ Hz ]');
    ylabel('Amplituda [mV / Hz]' );
    title('Spektar signala posle filtracije');
    grid on;
    %%
   
    figure
    subplot(3,1,1)
    plot(time(1:360*20), signal(1:360*20),  'Color', [0 0 0])
        xlabel('Vreme [s]')
        ylabel('Napon [mV]')
        title(['Prikaz prvih 20 sekundi signala pre filtriranja '])
        grid on;
    subplot(3,1,2)
    plot(time(1:360*20), filtered_signal(1:360*20), 'Color', [0 0 0])
        xlabel('Vreme [s]')
        ylabel('Napon [mV]')
        title(['Prikaz prvih 20 sekundi signala posle filtriranja']);
        grid on;
        
Ts = 1/fs;
f = 0.3;
n = 0:Ts:(length(filtered_signal)*Ts - Ts);
noise =amp*sin(2*pi*f*n);
modified_signal = filtered_signal + noise';

 subplot(3,1,3)
    plot(time(1:360*20), modified_signal(1:360*20), 'LineWidth', 2, 'Color', [0 0 0])
        xlabel('Vreme [s]')
        ylabel('Napon [mV]')
        title(['Sum pridruzen filtriranom signalu  ']);
        grid on;
%%
mz_dec = time(1:resampling:end);
y_dec = modified_signal(1:resampling:end);%industrijsko pravilo da najvisa frekvencija bude na 80% od fs/2;



y_dec = [0; y_dec; 0]; 
pp = spline(mz_dec, y_dec);

base_line_polynom_1 = ppval(pp,time);
%%


figure
    plot(time(1:30000) ,noise(1:30000),'Color', [0 0 0])
    hold on;
    plot(time(1:30000),base_line_polynom_1(1:30000)', 'LineWidth', 2.5 ,'Color','red')
        xlabel('Vreme [s]')
        ylabel('Napon [ mV ]')
        title('aproksimacija bazne linije')
        xlim([0 30000/360])
        grid on;
        legend('Bazna linija ', 'Procenjena bazna linija  ', 'Location', 'southeast');
    
        %%
%posto kod zdravih osoba trajanje qrs kompleksa prosecno iznosi oko 80 ms
%toliko ce iznositi i nasa sirina opsega oko 1 pika toliki ce biti opseg i
%kada vrsimo modifikaciju sa 0 umesto celog opsega i kada vrsimo
%modifikaciju zamene sa prvog vrednoscu pre tog opsega 
samples_per_band = floor(duration_of_band/Ts);
[pks,locs] = findpeaks(modified_signal,'MinPeakHeight',0.75);

modified_signal_temp = modified_signal ;
%prva modifikacija 
for i=1:length(locs)
    modified_signal_temp(locs(i)-round(samples_per_band/2):locs(i)+round(samples_per_band/2)) = 0;
     
end


figure
    plot(time(1:30000) ,modified_signal(1:30000),'Color', [0 0 0])
    hold on;
    plot(time(1:30000),modified_signal_temp(1:30000), 'LineWidth', 2.5 ,'Color','red')
        xlabel('Vreme [s]')
        ylabel('Napon [ mV ]')
        title('aproksimacija bazne linije')
        xlim([0 40]);
        grid on;
        legend('Signal PRE umetanja nula','Signal POSLE umetanja nula  ', 'Location', 'southeast');
    
mz_dec = time(1:resampling:end);
y_dec = modified_signal_temp(1:resampling:end);%industrijsko pravilo da najvisa frekvencija bude na 80% od fs/2;



y_dec = [0; y_dec; 0]; 
pp = spline(mz_dec, y_dec);

base_line_polynom_2 = ppval(pp,time);

%%

figure
    plot(time(1:30000) ,noise(1:30000),'Color', [0 0 0])
    hold on;
    plot(time(1:30000),base_line_polynom_2(1:30000), 'LineWidth', 2.5 ,'Color','red')
        xlabel('Vreme [s]')
        ylabel('Napon [ mV ]')
        title('aproksimacija bazne linije')
        xlim([0 30000/360])
        grid on;
        legend('Bazna linija ', 'Procenjena bazna linija  ', 'Location', 'southeast');
   
    %% 
    %druga modifikacija
samples_per_band = floor(duration_of_band/Ts);

modified_signal_temp_2 = modified_signal ;

for i=1:length(locs)
    modified_signal_temp_2(locs(i)-round(samples_per_band/2):locs(i)+round(samples_per_band/2)) = modified_signal_temp_2(locs(i)-round(samples_per_band/2)-1);
     
end

figure
    plot(time(1:30000) ,modified_signal(1:30000),'Color', [0 0 0])
    hold on;
    plot(time(1:30000),modified_signal_temp_2(1:30000), 'LineWidth', 2.5 ,'Color','red')
        xlabel('Vreme [s]')
        ylabel('Napon [ mV ]')
        title('aproksimacija bazne linije')
        xlim([0 40]);
        grid on;
        legend('Signal PRE poravanja ','Signal POSLE poravnanja   ', 'Location', 'southeast');
    
mz_dec = time(1:resampling:end);
y_dec = modified_signal_temp_2(1:resampling:end);%industrijsko pravilo da najvisa frekvencija bude na 80% od fs/2;



y_dec = [0; y_dec; 0]; 
pp = spline(mz_dec, y_dec);

base_line_polynom_3 = ppval(pp,time);
%%
figure
    plot(time(1:30000) ,noise(1:30000),'Color', [0 0 0])
    hold on;
    plot(time(1:30000),base_line_polynom_3(1:30000), 'LineWidth', 2.5 ,'Color','red')
        xlabel('Vreme [s]')
        ylabel('Napon [ mV ]')
        title('aproksimacija bazne linije')
        xlim([0 30000/360])
        grid on;
        legend('Bazna linija ', 'Procenjena bazna linija   ', 'Location', 'southeast');
         %%
    %provera stepena greske u oba slucaja da vidimo ko bolje radi
    %polinomijlno fitovanje 
    %koristicemo sumu kvadratnog korena razlike procenjene i stvarne
    %vrednosti
    
    squere_difference_1 = zeros(1,length(noise));
    squere_difference_2 = zeros(1,length(noise));
    squere_difference_3 = zeros(1,length(noise));
    %%
    for i = 1:length(noise)
        squere_difference_1(i)= sqrt((noise(i) - base_line_polynom_1(i)).^2)/amp;
        squere_difference_2(i) = sqrt((noise(i) - base_line_polynom_2(i)).^2)/amp;
        squere_difference_3(i) = sqrt((noise(i) - base_line_polynom_3(i)).^2)/amp;
    end
    

    %% ispravka

    X1 = ['Koeficijent odstupanja aproksimacije od stvarne vrednosti PRVOM metodom je ',num2str(mean(squere_difference_1))];
    X2 = ['Koeficijent odstupanja aproksimacije od stvarne vrednosti DRUGOM metodom je ',num2str(mean(squere_difference_2))];
    X3 = ['Koeficijent odstupanja aproksimacije od stvarne vrednosti TRECOM metodom je ',num2str(mean(squere_difference_3))];
    disp(X1)
    disp(X2)
    disp(X3)

