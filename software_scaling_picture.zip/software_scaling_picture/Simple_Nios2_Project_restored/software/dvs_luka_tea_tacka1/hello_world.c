#include "stdio.h"
#include "stdint.h"
#include "stdlib.h"
#include "altera_avalon_performance_counter.h"
#include "system.h"




int main()
{
	printf("Hello World! \n");
	PERF_RESET(PERFORMANCE_COUNTER_BASE);
	PERF_START_MEASURING(PERFORMANCE_COUNTER_BASE);

	FILE* picture;
	FILE* picture_out;
	uint32_t height, width;
	int scaleFactor;
	char scaleDirection;


	PERF_BEGIN(PERFORMANCE_COUNTER_BASE, 1);

	picture = fopen("/mnt/host/lena.bin", "rb"); //otvaramo sliku
	if (picture== NULL) { //upisujemo integer u scaleFactor
		printf("nece da ucita");
		return 0;}

	fread(&width, sizeof(uint32_t), 1, picture); //ucitavamo sirinu
	fread(&height, sizeof(uint32_t), 1, picture); //ucitavamo visinu

	printf("sirina slike: %lu\n", width);
	printf("visina slike: %lu\n", height);

	uint8_t *buffer = (uint8_t *)malloc(height*width); //alociramo prostor potreban za upis slike
	fread(buffer, sizeof(uint8_t), height*width, picture); //u alocirani prostor ubacujemo sliku

	PERF_END(PERFORMANCE_COUNTER_BASE, 1);

	fclose(picture);

	perf_print_formatted_report(PERFORMANCE_COUNTER_BASE, alt_get_cpu_freq(), 1, "Ucitavanje slike");
	PERF_STOP_MEASURING(PERFORMANCE_COUNTER_BASE);

	while(1){
		PERF_RESET(PERFORMANCE_COUNTER_BASE);
		PERF_START_MEASURING(PERFORMANCE_COUNTER_BASE);
		printf("Unesite faktor skaliranja:\n");
		int OK = 1;
		while(OK){
			if (scanf("%d", &scaleFactor) == 1) { //upisujemo integer u scaleFactor
				printf("Uneli ste faktor: %d\n", scaleFactor);
				OK = 0;
			}
		}

		printf("Unesite pravac(g/d):\n");
		OK = 1;
		while(OK){
			if (scanf("%c", &scaleDirection) == 1) { //upisujemo karakter u scaleDirection
				if (scaleDirection == 'g' || scaleDirection == 'd') { //proveravamo validnost upisanog karaktera
					printf("Uneli ste : %c\n", scaleDirection);
					OK = 0;
				} else {
					printf("Molimo Vas unesite ili g ili d.\n");
				}
			}
		}

		picture_out = fopen("/mnt/host/lena_scaled.bin", "wb");

		uint32_t width_scaled, height_scaled;
		if (scaleDirection == 'd') {

		    width_scaled = width / scaleFactor;
		    height_scaled = height / scaleFactor;
		} else if (scaleDirection == 'g') {

		    width_scaled = width * scaleFactor;
		    height_scaled = height * scaleFactor;
		} else {
		    width_scaled = width;
		    height_scaled = height;
		}
		uint8_t *buffer_scaled = (uint8_t *)malloc(width_scaled*height_scaled);

		printf("Zapocinjemo proces obrade \n");

		PERF_BEGIN(PERFORMANCE_COUNTER_BASE, 1);

		// downscale
		if (scaleDirection == 'd') {

		    for (int j = 0; j < height_scaled; j++) {
	            int orig_j = j * scaleFactor;
		        for (int k = 0; k < width_scaled; k++) {
		            int orig_k = k * scaleFactor; // iz ucitane slike uzimamo scalaFactor-ti pixel
		            buffer_scaled[j * width_scaled + k] = buffer[orig_j * width + orig_k];
		        }
		    }
		}

		// upscale
		if (scaleDirection == 'g') {
		    for (int j = 0; j < height_scaled; j++) {
	            int orig_j = j / scaleFactor;
		        for (int k = 0; k < width_scaled; k++) {
		            int orig_k = k / scaleFactor; //upisujemo istu vrednost pixela scaleFactor puta
		            buffer_scaled[j * width_scaled + k] = buffer[orig_j * width + orig_k];
		        }
		    }
		}

		PERF_END(PERFORMANCE_COUNTER_BASE, 1);

		printf("Proces zavrsen \n");

		PERF_BEGIN(PERFORMANCE_COUNTER_BASE, 2);
		fwrite(&width_scaled, sizeof(uint32_t), 1, picture_out);
		fwrite(&height_scaled, sizeof(uint32_t), 1, picture_out);
		fwrite(buffer_scaled, 1, width_scaled*height_scaled, picture_out);
		PERF_END(PERFORMANCE_COUNTER_BASE, 2);

		perf_print_formatted_report(PERFORMANCE_COUNTER_BASE, alt_get_cpu_freq(), 2, "g/d", "Writing file");
		PERF_STOP_MEASURING(PERFORMANCE_COUNTER_BASE);

		fclose(picture_out);
		free(buffer_scaled);
		printf("Unesite parametre naredne iteracije!\n");
	}
	return 0;
}
