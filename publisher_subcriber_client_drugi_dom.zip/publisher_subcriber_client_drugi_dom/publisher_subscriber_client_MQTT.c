

 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MQTTClient.h"
#include <time.h>
#include <winsock.h>
#include <stdbool.h>

#define ADDRESS     "broker.hivemq.com:1883"
#define CLIENTID    "ExampleClientPub"
#define TOPIC       "MQTT_publish_subscribe"



#define QOS         1
#define TIMEOUT     10000L

void *ThreadMain(void *arg);            /* Main program of a thread */

/* Structure of arguments to pass to client thread */
struct ThreadArgs
{
    MQTTClient* client;
    MQTTClient_message* pubmsg;
    MQTTClient_deliveryToken* token;
	                     /* Socket descriptor for client */
};


DWORD  threadID;      
bool proceed =true; 
clock_t before;
int sum = 0 ;
int total_counter = 0; 

volatile MQTTClient_deliveryToken deliveredtoken;

void delivered(void *context, MQTTClient_deliveryToken dt)
{
    //printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken = dt;
}

int msgarrvd(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int i;
    char* payloadptr;
    
    clock_t difference = clock() - before;
    int difference_in_ms = (int)(((double)difference / CLOCKS_PER_SEC) * 1000);
    
    sum += difference_in_ms ; 
    if(++total_counter == 100 )
	{
	   printf("Average time for QOS type %d is %d minutes and %d seconds\n",
       QOS,
       (int)(((double)sum / 100) / 1000),
       (int)(((double)sum / 100)) % 1000);
	   total_counter = 0 ;
	   sum = 0 ;
	}

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

void connlost(void *context, char *cause)
{
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}

int main(int argc, char* argv[])
{
	struct ThreadArgs *threadArgs;
    MQTTClient client;
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;
    int ch;

    MQTTClient_create(&client, ADDRESS, CLIENTID,
        MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;

    MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);

    if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    printf("Subscribing to topic %s\nfor client %s using QoS%d\n\n"
           "Press Q<Enter> to quit\n\n", TOPIC, CLIENTID, QOS);
    MQTTClient_subscribe(client, TOPIC, QOS);
    
    threadArgs = (struct ThreadArgs *) malloc(sizeof(struct ThreadArgs)); // u ovom primeru to je balanno jer je mala memorija alo ima logike da ne punimo stack u slucaju da ima milion klienta puci ce stack 
    threadArgs -> client = &client;
    threadArgs -> pubmsg = &pubmsg;
    threadArgs -> token = &token;
    
	HANDLE threadHandle;
    threadHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) ThreadMain, threadArgs, 0, &threadID);

	if (threadHandle == NULL)
    	printf("nije generisan thread\n");
	
    

    do 
    {
        ch = getchar(); 
    } while(ch!='Q' && ch != 'q');
    proceed = false ; 
    
    WaitForSingleObject(threadHandle, INFINITE);
	CloseHandle(threadHandle);

    MQTTClient_unsubscribe(client, TOPIC);
    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);
    return rc;
} 

void *ThreadMain(void *args)
{
	
	struct ThreadArgs* threadArgs = (struct ThreadArgs*) args;
	char load[30];
	int current_number = 0; 
	int rc;
	while(proceed)
	{
		if(++current_number==256) current_number = 0;
		sprintf(load, "Test message number: %d", current_number );
		threadArgs->pubmsg->payload = load;
		threadArgs->pubmsg->payloadlen = (int)strlen(load);
		threadArgs->pubmsg->qos = QOS;
		threadArgs->pubmsg->retained = 0;
		
		before = clock();
		
		MQTTClient_publishMessage(*(threadArgs->client), TOPIC, threadArgs->pubmsg, threadArgs->token);
		
		rc = MQTTClient_waitForCompletion(*(threadArgs->client), *(threadArgs->token), TIMEOUT);
		Sleep(100); // do something else
		
	}
	
	
    free(threadArgs);             



    return (NULL);
}
